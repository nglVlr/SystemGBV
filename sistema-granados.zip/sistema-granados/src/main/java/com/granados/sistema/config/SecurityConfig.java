package com.granados.sistema.config;

import com.granados.sistema.usuarios.entity.Rol;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Seguridad del sistema.
 *
 * Reglas de acceso por modulo:
 *   /admin/**  -> solo SUPERADMIN
 *   /dafim/**  -> ADMIN_DAFIM o SUPERADMIN
 *   /rrhh/**   -> ADMIN_RRHH o SUPERADMIN
 *   estaticos y /login -> publicos
 *   todo lo demas -> requiere sesion iniciada
 *
 * El login es el formulario propio en /login y el logout es POST con CSRF
 * (los formularios Thymeleaf ya incluyen el token automaticamente).
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/login", "/css/**", "/js/**", "/vendor/**",
                        "/img/**", "/favicon.ico", "/error").permitAll()
                .requestMatchers("/admin/**").hasRole(Rol.SUPERADMIN)
                .requestMatchers("/dafim/**")
                        .hasAnyRole(Rol.ADMIN_DAFIM, Rol.SUPERADMIN)
                .requestMatchers("/rrhh/**")
                        .hasAnyRole(Rol.ADMIN_RRHH, Rol.SUPERADMIN)
                .anyRequest().authenticated())
            .formLogin(form -> form
                .loginPage("/login")
                .defaultSuccessUrl("/", true)
                .failureUrl("/login?error")
                .permitAll())
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID"))
            .exceptionHandling(ex -> ex.accessDeniedPage("/error/403"));
        return http.build();
    }
}
