package com.granados.sistema.dafim.compras.parser;

import com.granados.sistema.dafim.compras.dto.RegistroGuatecompras;
import com.granados.sistema.dafim.compras.util.Constantes;
import com.granados.sistema.dafim.compras.util.TextoUtil;
import com.granados.sistema.dafim.compras.service.ValidadorComprasService;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Porteo EXACTO de parsear_txt(): publicaciones del mes en Guatecompras.
 *
 * El archivo es texto plano con un bloque por publicacion. Cada bloque
 * empieza con el NPG (E56/E57/E58 + 7 digitos) y trae en lineas fijas la
 * fecha (linea 1), la modalidad (linea 6), la descripcion (linea 7) y mas
 * abajo el NIT del proveedor seguido de su nombre. El monto es la ultima
 * linea numerica del bloque.
 */
public final class ParserGuatecompras {

    private static final Pattern RE_SPLIT = Pattern.compile("(?=E5[678]\\d{7})");
    private static final Pattern RE_NPG = Pattern.compile("^E5[678]\\d{7}$");
    private static final Pattern RE_MONTO = Pattern.compile("^\\d+\\.?\\d*$");
    private static final Pattern RE_NIT = Pattern.compile("^\\d+K?$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern RE_FECHA = Pattern.compile("(\\d+)\\.(\\w+)\\.(\\d{4})");

    private ParserGuatecompras() {}

    public static List<RegistroGuatecompras> parsear(String contenido) {
        List<RegistroGuatecompras> regs = new ArrayList<>();
        Set<String> vistos = new LinkedHashSet<>();

        String[] bloques = RE_SPLIT.split(contenido.strip());
        for (String bRaw : bloques) {
            String b = bRaw.strip();
            if (b.isEmpty()) continue;

            List<String> lines = new ArrayList<>();
            for (String l : b.split("\n")) {
                String t = l.strip();
                if (!t.isEmpty()) lines.add(t);
            }
            if (lines.size() < 8) continue;

            String npg = lines.get(0);
            if (!RE_NPG.matcher(npg).matches() || vistos.contains(npg)) continue;
            vistos.add(npg);

            double monto = 0.0;
            for (int i = lines.size() - 1; i >= 0; i--) {
                String t = lines.get(i).replace(",", "").strip();
                if (RE_MONTO.matcher(t).matches()) {
                    monto = Double.parseDouble(t);
                    break;
                }
            }

            String linea6 = lines.size() > 6 ? lines.get(6) : "";
            String modalidad = (linea6.contains("Art.43") || linea6.contains("Baja Cuant"))
                    ? "BAJA CUANTIA" : "CASO DE EXCEPCION";

            String nit = "";
            String proveedor = "";
            for (int i = 8; i < lines.size(); i++) {
                if (RE_NIT.matcher(lines.get(i)).matches()) {
                    nit = TextoUtil.limpiarNit(lines.get(i));
                    proveedor = i + 1 < lines.size() ? lines.get(i + 1) : "";
                    break;
                }
            }

            String fecha;
            Matcher m = RE_FECHA.matcher(lines.get(1));
            if (m.lookingAt()) {
                String dia = m.group(1);
                if (dia.length() < 2) dia = "0" + dia;
                String mesTxt = m.group(2).toLowerCase(Locale.ROOT);
                if (mesTxt.length() > 3) mesTxt = mesTxt.substring(0, 3);
                fecha = dia + "/" + Constantes.MES_MAP.getOrDefault(mesTxt, "00")
                        + "/" + m.group(3);
            } else {
                fecha = lines.get(1);
            }

            RegistroGuatecompras r = new RegistroGuatecompras();
            r.setNpg(npg);
            r.setFecha(fecha);
            r.setModalidad(modalidad);
            r.setDesc(lines.size() > 7 ? lines.get(7) : "");
            r.setNit(nit);
            r.setProveedor(proveedor);
            r.setMonto(ValidadorComprasService.round2(monto));
            regs.add(r);
        }
        return regs;
    }
}
