package com.granados.sistema.dafim.paquetes.repository;

import com.granados.sistema.dafim.paquetes.entity.FacturaSat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface FacturaSatRepository extends JpaRepository<FacturaSat, Long> {

    boolean existsByAutorizacion(String autorizacion);

    List<FacturaSat> findByAnioAndMesOrderByIdAsc(int anio, int mes);

    /** Todas las autorizaciones ya guardadas (para no reusar facturas). */
    @Query("select f.autorizacion from FacturaSat f")
    List<String> todasLasAutorizaciones();

    /** Facturas del mes que ninguna linea tiene asignada (libres). */
    @Query("select f from FacturaSat f where f.anio = :anio and f.mes = :mes "
            + "and f.id not in (select l.factura.id from LineaPaquete l "
            + "where l.factura is not null)")
    List<FacturaSat> libresDelMes(int anio, int mes);

    long countByAnioAndMes(int anio, int mes);

    void deleteByAnioAndMes(int anio, int mes);

    /** Busqueda global por numero de DTE (contiene, sin importar mayusculas), mas recientes primero. */
    List<FacturaSat> findByNumeroDteContainingIgnoreCaseOrderByAnioDescMesDescIdDesc(String dte);
}
