package com.granados.sistema.web;

import com.granados.sistema.usuarios.entity.Usuario;
import com.granados.sistema.usuarios.service.UsuarioService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Pantalla de inicio (dashboard general) y login.
 */
@Controller
public class DashboardController {

    private final UsuarioService usuarioService;

    public DashboardController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/")
    public String inicio(Authentication auth, Model model) {
        Usuario u = usuarioService.porUsername(auth.getName()).orElse(null);
        model.addAttribute("usuario", u);
        model.addAttribute("nombreMostrar",
                u != null && u.getNombreCompleto() != null
                        && !u.getNombreCompleto().isBlank()
                        ? u.getNombreCompleto() : auth.getName());
        return "dashboard";
    }

    @GetMapping("/error/403")
    public String accesoDenegado() {
        return "error/403";
    }
}
