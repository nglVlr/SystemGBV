package com.granados.sistema.usuarios.service;

import com.granados.sistema.usuarios.entity.Rol;
import com.granados.sistema.usuarios.entity.Usuario;
import com.granados.sistema.usuarios.repository.UsuarioRepository;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Adaptador entre la tabla usuarios y Spring Security.
 * Cada rol se expone como ROLE_{NOMBRE} para poder usar hasRole().
 */
@Service
public class UsuarioDetailsService implements UserDetailsService {

    private final UsuarioRepository usuarioRepo;

    public UsuarioDetailsService(UsuarioRepository usuarioRepo) {
        this.usuarioRepo = usuarioRepo;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Usuario u = usuarioRepo.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException(
                        "Usuario no encontrado: " + username));
        List<GrantedAuthority> auths = new ArrayList<>();
        for (Rol r : u.getRoles()) {
            auths.add(new SimpleGrantedAuthority("ROLE_" + r.getNombre()));
        }
        return User.builder()
                .username(u.getUsername())
                .password(u.getPassword())
                .disabled(!u.isActivo())
                .authorities(auths)
                .build();
    }
}
