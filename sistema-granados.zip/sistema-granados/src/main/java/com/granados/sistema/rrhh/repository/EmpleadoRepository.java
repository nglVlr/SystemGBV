package com.granados.sistema.rrhh.repository;

import com.granados.sistema.rrhh.entity.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmpleadoRepository extends JpaRepository<Empleado, Long> {

    List<Empleado> findByActivoTrueOrderByNombreAsc();

    List<Empleado> findAllByOrderByActivoDescNombreAsc();

    long countByActivoTrue();
}
