package com.granados.sistema.rrhh.repository;

import com.granados.sistema.rrhh.entity.Permiso;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface PermisoRepository extends JpaRepository<Permiso, Long> {

    List<Permiso> findAllByOrderBySolicitadoEnDesc();

    List<Permiso> findByEstadoOrderBySolicitadoEnDesc(String estado);

    long countByEstado(String estado);

    /** Permisos de un empleado dentro del anio (para el contador de dias). */
    List<Permiso> findByEmpleadoIdAndEstadoAndFechaInicioBetween(
            Long empleadoId, String estado, LocalDate desde, LocalDate hasta);

    long countByEstadoAndFechaInicioBetween(
            String estado, LocalDate desde, LocalDate hasta);
}
