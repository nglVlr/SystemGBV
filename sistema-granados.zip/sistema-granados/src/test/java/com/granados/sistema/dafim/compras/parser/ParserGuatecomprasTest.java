package com.granados.sistema.dafim.compras.parser;

import com.granados.sistema.dafim.compras.dto.RegistroGuatecompras;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ParserGuatecomprasTest {

    private static final String TXT = String.join("\n",
            "E568000010",
            "3.jun.2026",
            "Municipalidad de Granados",
            "Compra Directa",
            "Publicado",
            "linea 5",
            "Compra Directa con Oferta Electronica (Art.43 LCE Inciso b)",
            "MANTENIMIENTO DE VEHICULO MUNICIPAL PLACA O-123",
            "linea 8",
            "1111",
            "TALLER HERMANOS LOPEZ",
            "Q. 3,500.00",
            "3,500.00",
            "",
            "E568000011",
            "15.junio.2026",
            "Municipalidad de Granados",
            "Compra Directa",
            "Publicado",
            "linea 5",
            "Caso de Excepcion (Art. 44 LCE)",
            "SERVICIOS TECNICOS DE APOYO ADMINISTRATIVO",
            "linea 8",
            "123456K",
            "ANA LUCIA MENDEZ SIS",
            "2,900.00");

    @Test
    void separaPublicacionesYExtraeCampos() {
        List<RegistroGuatecompras> regs = ParserGuatecompras.parsear(TXT);
        assertEquals(2, regs.size());

        RegistroGuatecompras r0 = regs.get(0);
        assertEquals("E568000010", r0.getNpg());
        assertEquals("03/06/2026", r0.getFecha());
        assertEquals("BAJA CUANTIA", r0.getModalidad());
        assertEquals("1111", r0.getNit());
        assertEquals("TALLER HERMANOS LOPEZ", r0.getProveedor());
        assertEquals(3500.00, r0.getMonto());

        RegistroGuatecompras r1 = regs.get(1);
        assertEquals("15/06/2026", r1.getFecha());
        assertEquals("CASO DE EXCEPCION", r1.getModalidad());
        assertEquals("123456", r1.getNit());
        assertEquals(2900.00, r1.getMonto());
    }
}
