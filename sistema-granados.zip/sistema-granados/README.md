# Sistema Granados

Sistema web interno de la **Municipalidad de Granados, Baja Verapaz** con tres modulos:

| Modulo | Ruta | Quien lo usa |
|---|---|---|
| **DAFIM · Compras directas** | `/dafim/compras` | ADMIN_DAFIM |
| **Recursos Humanos** (en construccion) | `/rrhh` | ADMIN_RRHH |
| **Usuarios del sistema** | `/admin/usuarios` | SUPERADMIN |

El modulo de compras genera el **informe mensual de compras y contrataciones**
(Art. 10, Numeral 11, Ley de Acceso a la Informacion Publica) a partir de tres
archivos: el reporte de cheques del banco, el TXT de publicaciones de
Guatecompras y el PDF de SICOIN. Es el mismo motor que ya se usaba en Google
Colab, portado a Java con **paridad verificada linea por linea** (ver la
seccion "Como se verifico" al final).

---

## 1. Requisitos

* **Java 17** o superior (JDK). En Windows: instalar por ejemplo
  [Eclipse Temurin 17](https://adoptium.net/).
* **IntelliJ IDEA** (Community es suficiente) o cualquier IDE con soporte Maven.
* **WampServer** corriendo (el sistema usa su MySQL en `localhost:3306`).
* Conexion a internet la primera vez (Maven descarga las dependencias).

## 2. Puesta en marcha

1. **Descomprime** el proyecto donde quieras, por ejemplo
   `C:\proyectos\sistema-granados`.
2. **Abre IntelliJ** y elige `Open...` apuntando a la carpeta del proyecto.
   IntelliJ detecta el `pom.xml` y descarga las dependencias (espera a que
   termine la barra de progreso).
3. **Enciende WampServer** (icono verde). No hace falta crear la base de
   datos: el sistema la crea solo (`sistema_granados`) la primera vez, junto
   con todas las tablas y los usuarios iniciales.
   * Si prefieres crearla a mano, en phpMyAdmin ejecuta
     `database/01_schema.sql` y despues `database/02_datos_iniciales.sql`.
4. **Ejecuta** la clase `SistemaGranadosApplication`
   (`src/main/java/com/granados/sistema/SistemaGranadosApplication.java`)
   con el boton verde de IntelliJ, o desde consola:

   ```
   mvnw spring-boot:run        (Windows: mvnw.cmd spring-boot:run)
   ```

5. Abre el navegador en **http://localhost:8085**

Si el puerto 8085 esta ocupado, cambialo en
`src/main/resources/application.properties` (`server.port`).

### Usuarios iniciales

| Usuario | Contrasena | Rol |
|---|---|---|
| `superadmin` | `Granados2026*` | SUPERADMIN |
| `admin_dafim` | `Dafim2026*` | ADMIN_DAFIM |
| `admin_rrhh` | `Rrhh2026*` | ADMIN_RRHH |

**Importante:** despues del primer ingreso, entra como `superadmin` a
`Usuarios del sistema` y cambia las tres contrasenas.

### Si tu MySQL tiene contrasena de root

Edita `application.properties`:

```
spring.datasource.username=root
spring.datasource.password=TU_CONTRASENA
```

---

## 3. Flujo mensual de DAFIM (el trabajo de cada mes)

1. Entra con `admin_dafim` y ve a **Procesar el mes**.
2. Elige mes y anio, y sube los tres archivos de siempre:
   * Reporte de **cheques** del banco (`.xls` o `.xlsx`)
   * **TXT** de publicaciones de Guatecompras
   * **PDF** de SICOIN (detalle de gastos por proveedor)
   * Opcional: planilla de **remuneraciones** para cruzar el personal 029
3. Pulsa **Procesar**. El sistema:
   * cruza cada cheque con SICOIN y Guatecompras,
   * completa NPG, contrato y cargo del personal 029 usando la base historica,
   * valida todo al centavo (acta de validacion),
   * compara contra el mes anterior (quien entro, quien salio, cambios de
     monto en 029),
   * y genera el **Excel legal** con el formato oficial de 15 columnas.
4. Revisa en pantalla las **alertas** (cheques sin cruce, personal nuevo,
   pagos sin NIT) y descarga el Excel para verlo.
5. Si todo esta bien: **Confirmar y guardar en la BD**. Hasta ese momento
   nada se guarda; si algo no cuadra puedes **Descartar** y volver a procesar.

Los archivos que subes quedan respaldados en `storage/uploads` y los Excel
generados en `storage/generados`, con fecha y hora en el nombre.

## 4. Cargas historicas (una sola vez, para alimentar la BD)

* **Cargar NPGs**: sube los PDFs de confirmacion de publicacion de
  Guatecompras del personal 029 (varios a la vez o un ZIP). El sistema
  extrae NPG, NIT, nombre y contrato y actualiza la base.
* **Cargar machote**: para meses que ya se trabajaron a mano en Excel.
  Eliges mes y anio, subes el archivo, revisas la vista previa y confirmas:
  se suma al historial y alimenta contratos y proveedores. Si el renglon
  viene vacio, el sistema lo infiere por la descripcion.

## 5. Consultas

* **Buscar en la BD**: por NIT o por nombre (ignora tildes y mayusculas).
  Muestra contratos 029, proveedores y todos los pagos del historial.
* **Resumen**: totales por mes, monto acumulado y top 10 por monto.
* **Exportar la BD**: descarga un Excel con las tres tablas completas.

---

## 6. Estructura del proyecto

```
sistema-granados/
├── pom.xml                      dependencias (Spring Boot 3, POI, PDFBox)
├── database/                    scripts SQL de referencia
├── storage/                     archivos subidos y Excel generados (se crea sola)
└── src/
    ├── main/java/com/granados/sistema/
    │   ├── SistemaGranadosApplication.java
    │   ├── config/              seguridad, almacenamiento, datos iniciales
    │   ├── usuarios/            entidades, servicio y pantalla de usuarios
    │   ├── web/                 dashboard y login
    │   ├── rrhh/                modulo RRHH (en construccion)
    │   └── dafim/compras/
    │       ├── util/            norm, fechas, contratos, catalogos
    │       ├── dto/             estructuras de datos del motor
    │       ├── parser/          lectores: cheques, TXT, SICOIN, NPG, machote
    │       ├── service/         MOTOR (paridad con el Colab), validador,
    │       │                    comparador, generador de Excel, BD
    │       └── web/             controlador del modulo
    ├── main/resources/
    │   ├── application.properties
    │   ├── templates/           pantallas Thymeleaf
    │   └── static/              css, js, escudo, fuentes (todo local, sin CDN)
    └── test/java/               pruebas JUnit (mvn test)
```

## 7. Pruebas

```
mvnw test        (Windows: mvnw.cmd test)
```

Corre 35 pruebas de utilerias, motor, validador, comparador y parsers,
incluido un viaje redondo del Excel legal (se genera y se vuelve a leer).
Hay dos pruebas desactivadas con `@Disabled` que esperan PDFs reales: si
quieres activarlas, coloca un PDF de SICOIN y uno de confirmacion NPG en
`src/test/resources/parser/` y quita la anotacion.

## 8. Subir a GitHub

```
git init
git add .
git commit -m "Sistema Granados: version inicial"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/sistema-granados.git
git push -u origin main
```

El `.gitignore` ya excluye `target/`, `storage/` y archivos del IDE.

## 9. Problemas frecuentes

* **"Communications link failure" al arrancar**: WampServer no esta
  encendido o MySQL no corre en el puerto 3306.
* **"Access denied for user root"**: tu MySQL tiene contrasena; ponla en
  `application.properties`.
* **El navegador no abre nada**: revisa la consola de IntelliJ; el sistema
  imprime `Tomcat started on port 8085` cuando ya esta listo.
* **Subi un archivo equivocado**: el sistema avisa con un mensaje claro
  (por ejemplo "no se encontraron cheques con estado IMPRESO"); vuelve a
  procesar con el archivo correcto.
* **Un mes quedo mal guardado**: procesalo de nuevo y confirma; el sistema
  reemplaza los registros anteriores de ese mes y te avisa cuantos reemplazo.
* **Archivo muy grande**: el limite es 20 MB por archivo (configurable en
  `application.properties`).

## 10. Como se verifico este porteo

* **Paridad del motor**: se ejecuto el motor Python original y el motor Java
  con exactamente las mismas entradas (13 cheques que cubren todos los
  caminos: match directo, lineas multiples, fuzzy 029, keywords, NPG
  historico, anti duplicados, personal nuevo, sin NIT, machote, historial
  con renglon `29` sin ceros, etc.). Las salidas fueron **identicas**:
  filas, alertas, acta de validacion, cruce de remuneraciones, comparacion
  mensual y datos para la BD.
* **Parsers**: probados contra archivos reales `.xls` y textos con el mismo
  formato de los reportes (35 pruebas JUnit en verde).
* **SQL**: los scripts de `database/` se ejecutaron contra MariaDB y son
  idempotentes (se pueden correr dos veces sin duplicar nada).

## 11. Calibracion con datos reales (junio 2026)

El sistema se calibro contra el mes de junio 2026 completo, comparando la
salida del motor Java contra el Excel generado por el Colab original con
los mismos archivos (PDF SICOIN de 51 paginas, reporte de cheques .xls,
bloque TXT de Guatecompras):

- 543 filas generadas, identicas en numero al informe real.
- Total del mes Q2,951,154.59 cuadrado al centavo.
- Modalidades: 278 BAJA CUANTIA y 265 CASO DE EXCEPCION, igual al informe.
- Montos, renglones, NITs, proveedores, fechas y contratos: 0 diferencias.
- NPGs: los 275 publicados en el TXT del mes se asignan igual; los 265
  restantes salen de la BD historica (se llenan al cargar los machotes o
  los PDFs de NPG de meses anteriores).
- Descripciones: se corrigio el layout de PDFBox (la fuente de
  financiamiento venia pegada a la continuacion del texto). En 15 casos
  el Java quedo incluso MAS limpio que el Colab, que arrastraba texto
  duplicado de la transaccion vecina.
- Los PDFs reales quedaron como recursos de prueba en
  `src/test/resources/parser/` y los 36 tests JUnit pasan.

## 12. NPGs: carga por PDF, ZIP o manual

En `/dafim/compras/cargar-npgs` se puede:

- Subir VARIOS PDFs de confirmacion a la vez, o un solo ZIP con todos.
- Ingresar un NPG a mano (NPG, NIT, nombre, contrato opcional) cuando no
  se tiene el PDF o viene en un formato raro.
- El lector de PDFs ahora tolera formatos alternativos de la constancia:
  si no encuentra "Publicacion (NPG)" usa el E-numero mas repetido del
  documento, y reconoce variantes de "NIT" y "Descripcion".

## 13. Paquetes de facturas SAT

En `/dafim/paquetes` se procesa el envio mensual de la oficina:

1. Se sube el Excel de paquetes (CADA HOJA es un paquete, con columnas de
   concepto y monto; la ultima fila con monto y sin concepto es el total)
   junto con TODAS las facturas FEL en PDF, sueltas o en un solo ZIP, sin
   importar el orden.
2. El sistema lee cada factura (autorizacion, serie, DTE, NIT y nombre del
   emisor, fecha, monto y descripcion) y casa cada linea de cada paquete
   con UNA factura: monto exacto al centavo y la descripcion mas parecida
   (tolera tildes, typos y espacios dobles).
3. Cuando varias facturas traen la misma descripcion y monto, se asignan
   una a una en el orden de los paquetes: el numero de autorizacion es
   UNICO en la base de datos, asi que una factura jamas se repite, ni
   siquiera contra meses anteriores ya guardados.
4. Todo queda en la BD por mes (paquetes, lineas, facturas y sus PDFs) y
   cada paquete se imprime como UN SOLO PDF con las facturas en el orden
   del Excel: se manda a imprimir paquete por paquete y en fisico solo se
   engrapan.
5. Las lineas que quedaron pendientes se pueden resolver a mano con el
   selector de facturas libres del mes (solo permite montos iguales).

Calibrado con el Excel real de julio 2026 (8 paquetes, 244 lineas,
Q1,981,000, todos los totales cuadran al centavo) y con una factura FEL
real de la SAT que quedo como prueba de regresion en
`src/test/resources/parser/factura.pdf`.

## 14. Instalar como servidor local en la Municipalidad

Guia completa paso a paso (IP fija, contrasena de MySQL, firewall, servicio
de Windows que arranca solo, respaldos automaticos) en
`servidor/LEEME_SERVIDOR.md`.

Resumen: `mvn package` genera un .jar ejecutable con todo incluido. Se
copia a la maquina servidor, se corre con `java -jar sistema-granados.jar`
(o como servicio de Windows con NSSM para que no dependa de dejar una
ventana abierta), y las demas maquinas de la red LAN entran por navegador
a `http://IP_DEL_SERVIDOR:8085`. Como `ddl-auto=update` esta activo,
agregar modulos nuevos en el futuro nunca borra los datos existentes.

---

Municipalidad de Granados, Baja Verapaz · DAFIM
